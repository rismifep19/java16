package com.informatika.databarang.adapter
import android.app.AlertDialog
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.ViewParent
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.informatika.databarang.model.DataItem
import com.informatika.databarang.model.ResponseActionBarang
import network.koneksi
import org.junit.runner.manipulation.Ordering
import java.security.AccessControlContext
import javax.security.auth.callback.Callback
import ...

class ListContent(val ldata : List<DataItem?>?, val context: Context) :
        RecyclerView.Adapter<ListContent.ViewHolder>(){
            val namaBarang = view.findViewById<TextView>(R.id.tv_nama_barang)
            val jmlBarang = view.findViewById<TextView>(R.id.jumlah)
            val editBarang = view.findViewById<TextView>(R.id.tv_edit)
             val deleteBarang = view.findViewById<TextView>(R.id.tv_delete)
        }

override fun onBindViewHolder(parent: ViewGroup, viewType : Int): ViewHolder {
    val view = LayoutInflater.from(context).inflate(R.layout.item_barang, parent, attachToRoot: false)
    return ViewHolder(view)
}
override fun getItemCount(){
    return ViewHolder(view)

}
override fun onBindViewHolder(holder: ViewHolder, position: Int) {
    val model = ldata?.get(position)
    holder.namaBarang.text = model?.namaBarang
    holder.jmlBarang.text = model?.jumlahBarang
    holder.editBarang.setOnClickListener { it: View!
            val i = Intent(context, UpdateDataActivity::class.java)
        i.putExtra( name: "IDBARANG", model?.id)
        i.putExtra( name: "NAMABARANG".model?.namaBarang)
        i.putExtra( name: "JMLBARANG".model?.jumlahBarang)
        context.startActivity(i)
}
    holder.deleteBarang.setOnClickListener {
        AlertDialog.Builder(context)
            .setTitle("Delete: + model?.namaBarang")
            .setMessage("Apakah Anda Ingin Menghapus Data Ini?")
            .setPositiveButton("Ya"), DialogInterface.OnClickListener { dialog, which ->

                koneksi.service.deleteBarang(model?.id).enqueue(object : Callback<ResponseActionBarang>{
                    override fun onFailure(call<ResponseActionBarang>, t: Throwable) {
                        Log.d("pesan", t.localizedMessage)
                    }

                    override fun onResponse(
                        call: call<ResponseActionBarang>,
                        response: Response<ResponseActionBarang>
                    )}
                    if(response.isSuccessfull){
                        Toast.makeText(context, "Data Berhasil Dihapus", Toast.LENGTH_LONG.show()
                            notifyDataSetChanged()
                            notifyItemRemoved(position)
                            notifyItemChanged(position)
                            notifyItemRangeRemoved(position, ldata!!.size)
                        Log.d("bpesan", response.body().toString())
                    }
    }}
})
})
.setNegativeButton("No", DiaogInterface.OnClickListener { dialog, which ->
dialog.cancel()
    })
        .show()
}
}
}

