package com.informatika.databarang.model
import com.google.gson.annotations.SeriallizedName
data class ResponseBarang(
    @field:SerializedName( value: "pesan")
    val pesan: String? = null,

    @field:SerializedName( value: "data")
    val data: List<DataItem?>? = null,

    @field:SerializedName( value: "status")
    val status: Boolean? = null
)

        data class DataItem(
            @field:SerializedName( value: "Nama_barang")
            val namaBarang: String? = null,

            @field:SerializedName( value: "Id")
            val Id: String? = null,

            @field:SerializedName( value: "jumlah_barang")
            val jumlahbarang: String? = null
)